﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainInfo
{
    class SearchTrain
    {
        public string adultcharge { get; set; }
        public string depplacename { get; set; }
        public string depplandtime { get; set; }
        public string arrplacename { get; set; }
        public string arrplandtime { get; set; }
        
        public string traingradename { get; set; }
        public string trainno { get; set; }
        public string duration { get; set; }

    }
}
