	



	   function fn(divName) 
	   {
	    var frm = document.getElementById(divName);
	    
	    if (frm.style.display != "block") 
	    {
	     frm.style.display = "block";
	    } else {
	     frm.style.display = "none";
	    }
	   }
	   

