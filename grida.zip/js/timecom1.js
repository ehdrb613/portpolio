function timecom()
{
	var time = document.getElementById("output").value;
	alert(time);
}