<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


</body>
</html>


<?php

	$time = 0;
	$running = 0;

	function start
	{
		if($running == 0)
		{

		}
	}

?>