<?php


echo  'rand() : '.rand(1,2).'<br>';

echo $random;



?>